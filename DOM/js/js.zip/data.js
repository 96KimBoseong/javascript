const shoppingList = [
  {
    id: "sam05",
    name: "1953세트 2호",
    price: 9000,
    src: "./js/images/best_04.png"
  },
  {
    id: "sam04",
    name: "캠핑어묵탕",
    price: 5000,
    src: "./js/images/best_01.png"
  },
  {
    id: "sam03",
    name: "모듬어묵",
    price: 4000,
    src: "./js/images/best_02.png"
  },
  {
    id: "sam02",
    name: "실속모듬어묵",
    price: 7000,
    src: "./js/images/best_03.png"
  },
  {
    id: "sam01",
    name: "1953세트 2호",
    price: 9000,
    src: "./js/images/best_04.png"
  },
]

export default shoppingList